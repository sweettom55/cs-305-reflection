package com.snhu.sslserver;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

@RestController
public class HashController {

    @GetMapping("/hash")
    public String getHash() {
        // Step 1: Unique data string
        String data = "Thomas Sweet 2025-CS305";  // Customize this
        String algorithm = "SHA-256";

        try {
            // Step 2: Create hash
            MessageDigest digest = MessageDigest.getInstance(algorithm);
            byte[] encodedhash = digest.digest(data.getBytes(StandardCharsets.UTF_8));

            // Step 3: Convert to hex
            StringBuilder hexString = new StringBuilder();
            for (byte b : encodedhash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) hexString.append('0');
                hexString.append(hex);
            }

            // Step 4: Return readable output
            return "<h2>Developer: Thomas Sweet</h2>"
                    + "<p>Data: " + data + "</p>"
                    + "<p>Algorithm: " + algorithm + "</p>"
                    + "<p>Checksum: " + hexString + "</p>";

        } catch (NoSuchAlgorithmException e) {
            return "Error generating checksum: " + e.getMessage();
        }
    }
}
